# streaming-box

This project was generated with [Ionic CLI](https://ionicframework.com/docs/intro/cli) version 6.17.1.

## Development server

Run `ionic serve` for a dev server. Navigate to `http://localhost:8100/`. The app will automatically reload if you change any of the source files.


## Building Movie Streaming Cross Platform UI Design 

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://i.ytimg.com/vi/npdeG0ZDewY/maxresdefault.jpg)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

## Preview Screen Shots

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://user-images.githubusercontent.com/47156072/134695889-59a23001-1ce4-4a4c-a13d-4d3bf5524d9b.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://github.com/itsmearunsank/streaming-box/releases/download/screenshot_preview/movies_detail.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://github.com/itsmearunsank/streaming-box/releases/download/screenshot_preview/movies_filter.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://github.com/itsmearunsank/streaming-box/releases/download/screenshot_preview/tvshows.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://github.com/itsmearunsank/streaming-box/releases/download/screenshot_preview/tvshows_detail.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")

[![Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular](https://github.com/itsmearunsank/streaming-box/releases/download/screenshot_preview/search_page.png)](https://www.youtube.com/watch?v=npdeG0ZDewY "Free Tutorial - Building Movie Streaming Cross Platform UI Design | #Ionic Framework & #Angular")
